/*
  Warnings:

  - A unique constraint covering the columns `[name]` on the table `data_plans` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[name]` on the table `operator_cards` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[code]` on the table `payment_methods` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[url]` on the table `tips` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[code]` on the table `transaction_types` will be added. If there are existing duplicate values, this will fail.

*/
-- CreateIndex
CREATE UNIQUE INDEX "data_plans_name_key" ON "data_plans"("name");

-- CreateIndex
CREATE UNIQUE INDEX "operator_cards_name_key" ON "operator_cards"("name");

-- CreateIndex
CREATE UNIQUE INDEX "payment_methods_code_key" ON "payment_methods"("code");

-- CreateIndex
CREATE UNIQUE INDEX "tips_url_key" ON "tips"("url");

-- CreateIndex
CREATE UNIQUE INDEX "transaction_types_code_key" ON "transaction_types"("code");
