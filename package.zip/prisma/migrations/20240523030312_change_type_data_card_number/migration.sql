-- AlterTable
ALTER TABLE "wallets" ALTER COLUMN "cardNumber" SET DATA TYPE TEXT;
